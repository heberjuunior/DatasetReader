import React, { Component } from 'react';
import './App.css';
import Home from './Home';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import List from './List';
import Edit from './Edit';


class App extends Component {
  render() {
    return (
        <Router>
          <Switch>
            <Route path='/' exact={true} component={Home}/>
            <Route path='/learnings' exact={true} component={List}/>
            <Route path='/learnings/:id' component={Edit}/>
          </Switch>
        </Router>
    )
  }
}

export default App;