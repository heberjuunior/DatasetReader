import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import AppNavbar from './AppNavbar';

class Edit extends Component {

    constructor(props) {
        super(props);
        this.state = {
            item: this.emptyItem
        };
        this.handleChange = this.handleChange.bind(this);
        //this.handleSubmit = this.handleSubmit.bind(this);
    }

    emptyItem = {
        districtName: '',
        operationalSchools: '',
        studentCount: '',
        learningModality: ''
    };

    async componentDidMount() {
        if (this.props.match.params.id !== 'new') {
            const learning =   await(await fetch(`/api/learnings/${this.props.match.params.id}`)).json();
            this.setState({item: learning});
            

        }
    }

    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        let item = {...this.state.item};
        item[name] = value;
        this.setState({item});
    }

  

    

    render() {
        const {item} = this.state;
        console.log("ITEM:"+item)
        const title = <h2>{item.id ? 'Edit Learning' : 'Add  Learning'}</h2>;
    
        return <div>
            <AppNavbar/>
            <Container>
                {title}
                <Form onSubmit={this.handleSubmit}>
                    <FormGroup>
                        <Label for="districtName">District Name</Label>
                        <Input type="text" onChange={this.handleChange} name="districtName" id="districtName" value={item.districtName || ''}/>
                    </FormGroup>

                    <FormGroup>
                        <Label for="operationalSchools">Operational Schools</Label>
                        <Input type="text" onChange={this.handleChange} name="operationalSchools" id="operationalSchools" value={item.operationalSchools || ''}/>
                    </FormGroup>

                    <FormGroup>
                        <Label for="studentCount">Student Count</Label>
                        <Input type="text" onChange={this.handleChange} name="studentCount" id="studentCount" value={item.studentCount || ''}/>
                    </FormGroup>

                    <FormGroup>
                        <Label for="learningModality">Learning Modality</Label>
                        <Input type="text" onChange={this.handleChange} name="learningModality" id="learningModality" value={item.learningModality || ''}/>
                    </FormGroup>

                    <FormGroup>
                        <Button color="primary" type="submit">Save</Button>{' '}
                        <Button color="secondary" tag={Link} to="/learnings">Cancel</Button>
                    </FormGroup>

                </Form>
            </Container>
        </div>
    }
}
export default withRouter(Edit);