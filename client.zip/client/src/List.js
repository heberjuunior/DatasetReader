import React, { Component } from 'react';
import { Button, ButtonGroup, Container, Table } from 'reactstrap';
import AppNavbar from './AppNavbar';
import { Link } from 'react-router-dom';

class List extends Component {

    constructor(props) {
        super(props);
        this.state = {learnings: []};
    
    }

    render() {
        const {learnings} = this.state;
        console.log('learnings'+learnings)
        const clientList = learnings.map(l => {
            return <tr key={l.id}>
                <td/>
                <td style={{whiteSpace: 'nowrap'}}>{l.districtName}</td>
                <td style={{whiteSpace: 'nowrap'}}>{l.operationalSchools}</td>
                <td style={{whiteSpace: 'nowrap'}}>{l.studentCount}</td>
                <td>{l.learningModality}</td>
                <td>
                    <ButtonGroup>
                        <Button size="sm" color="primary" tag={Link} to={"/learnings/" + l.id}>Edit</Button>
                        <Button size="sm" color="danger" onClick={() => this.remove(l.id)}>Delete</Button>
                    </ButtonGroup>
                </td>
            </tr>
        });

        return (
            <div>
                <AppNavbar/>
                <Container fluid>
                    <div className="float-right">
                        <Button color="success" tag={Link} to="/learnings/new">New</Button>
                    </div>
                    <h3 align="center">Learnings</h3>
                    <Table className="mt-4">
                        <thead>
                        <tr>
                            <th width="2%"/>
                            <th width="10%">District Name</th>
                            <th width="10%">Operational Schools</th>
                            <th width="10%">Student Count </th>
                            <th width="10%">Modality</th>
                            <th width="10%">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {clientList}
                        </tbody>
                    </Table>
                </Container>
            </div>
        );
    }

    componentDidMount() {
        console.log('iniciando requisicao')
        fetch('/api/learnings')
            .then(response => response.json())
            .then(data => this.setState({learnings: data}));
    }
}
export default List;