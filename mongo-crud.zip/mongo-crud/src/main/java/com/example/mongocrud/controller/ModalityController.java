package com.example.mongocrud.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mongocrud.domain.Dataset;
import com.example.mongocrud.domain.Modality;
import com.example.mongocrud.service.DatasetService;

@RestController
@RequestMapping("/api/learnings")
public class ModalityController {
	
	@Autowired
	private DatasetService service;
	
	@GetMapping
	public ResponseEntity read(){
		
		return new ResponseEntity(fromDataSetToModality(service.findAll()), HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity findById(@PathVariable String id){
		Modality modality = fromDataSetToModality(service.findAll())
				.stream().filter(i-> i.getId().equals(id)).findFirst().get();
		
		
		return new ResponseEntity(modality, HttpStatus.OK);
		
		
		
	}
	
	public List<Modality> fromDataSetToModality(List<Dataset> datasets){
		Dataset dataset = datasets.get(0);
		Object[] data = dataset.getData();
		return fromDataSet(data);
	}
	
	private List<Modality> fromDataSet(Object[] data) {
		List<Modality> list = new ArrayList<>();
		for(Object object : data) {
			ArrayList arrayList = (ArrayList)object;
			Modality modality = new Modality();
			modality.setId((String)arrayList.get(0));
			modality.setDistrictName((String)arrayList.get(9));
			modality.setLearningModality((String)arrayList.get(11));
			modality.setStudentCount((String)arrayList.get(12));
			modality.setOperationalSchools((String)arrayList.get(13));
			modality.setCity((String)arrayList.get(14));
			modality.setState((String)arrayList.get(15));
		    list.add(modality);
		}
		return list;
	}

}
