package com.example.mongocrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mongocrud.domain.Dataset;
import com.example.mongocrud.repository.DatasetRepository;

@Service
public class DatasetService {

	@Autowired
	private DatasetRepository repository;
	
	public List<Dataset> findAll(){
		return repository.findAll();
	}
	
}
