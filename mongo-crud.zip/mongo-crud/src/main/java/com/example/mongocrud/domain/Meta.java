package com.example.mongocrud.domain;

public class Meta {
	private View view;

	public View getView() {
		return view;
	}

	public void setView(View view) {
		this.view = view;
	}
	
	

}
