package com.example.mongocrud.domain;

public class Modality {
	
	private String id;
	private String districtName; //9
	private String learningModality;//11;
	private String operationalSchools;//12
	private String studentCount;//13;
	private String city;//14;
	private String state;//15;
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public String getLearningModality() {
		return learningModality;
	}
	public void setLearningModality(String learningModality) {
		this.learningModality = learningModality;
	}
	public String getOperationalSchools() {
		return operationalSchools;
	}
	public void setOperationalSchools(String operationalSchools) {
		this.operationalSchools = operationalSchools;
	}
	public String getStudentCount() {
		return studentCount;
	}
	public void setStudentCount(String studentCount) {
		this.studentCount = studentCount;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
	

}
