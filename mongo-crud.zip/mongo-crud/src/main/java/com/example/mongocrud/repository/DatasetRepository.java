package com.example.mongocrud.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.mongocrud.domain.Dataset;

@Repository
public interface DatasetRepository
extends MongoRepository<Dataset, String>{

}
