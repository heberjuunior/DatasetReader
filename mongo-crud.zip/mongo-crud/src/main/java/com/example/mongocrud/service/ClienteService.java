package com.example.mongocrud.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.mongocrud.domain.Cliente;
import com.example.mongocrud.repository.ClienteRepository;

@Service
public class ClienteService {

	@Autowired
	private ClienteRepository repository ;

	public Cliente save(Cliente cliente) {
		return repository.save(cliente);
	}

	public List<Cliente> findAll() {
		return repository.findAll();
	}

}
